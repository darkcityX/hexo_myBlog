---
name: General issue
about: General questions for more information.
title: "[Question]：description"
labels: Help wanted, Question
assignees: Sariay

---

**为避免无效问题和冗余问题，提问前请确认**
- [ ] 你确定Google不能解决你的问题
- [ ] 你确定已有的issue不能解决你的问题
- [ ] 你确定issue的title按照格式如下：[type]：description
